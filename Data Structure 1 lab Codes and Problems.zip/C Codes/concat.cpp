#include<iostream>
#include<string>
using namespace std;


int main()
{
    string s1,s2,word1=" ",word2=" ";
    int n1,n2;
    cout<<"How many Word you want to enter in word1?";
    cin>>n1;
    for(int i=0;i<n1;i++)
    {
        cin>>s1;
        word1=word1+s1;
    }
    cout<<"How many Word you want to enter in word2?";
    cin>>n2;
    for(int i=0;i<n2;i++)
    {
        cin>>s2;
        word2=word2+s2;
    }
    if(word1.length() == word2.length()){
        
        for(int i=0;i<word1.length();i++){
            word1[i]=tolower(word1[i]);
            word2[i]=tolower(word2[i]);a
            if(word1[i] != word2[i]){
                cout<<"false";
                return 0;
            }
           }
        cout<<"true";
    }
    else{
        cout<<"false";
    }    
    return 0;    
}