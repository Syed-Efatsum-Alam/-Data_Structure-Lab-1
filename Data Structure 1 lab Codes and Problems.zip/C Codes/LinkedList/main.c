#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;

};struct node *head, *temp, *temp1;

void lastInsertion(int n)
{
    temp1 = head;
    while (temp1->next != NULL)
    {
        temp1 = temp1->next;
    }
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp -> next = NULL;
    temp1->next = temp;
}
void Fisrt_Insertion(int n)
{
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = head;
    head = temp;
}

void print_list()
{
    struct node *t;
    t = head;
    while (t != NULL)
    {
        printf("%d   ", t->data);
        t = t->next;
    }
}

int Totaldata(head)
{

    temp = head;
    int count = 0;
    if(temp->data==-1){
            return 0;

    }
    else{
        while (temp != NULL)
    {
        temp = temp->next;
        count++;
    }
    }

    return count;
}
int main()
{

    int a = 1;

    while (a != -1)
    {

        if (head != NULL)
        {

            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            if (a != -1)
                // LastInsertion(a);
                Fisrt_Insertion(a);
            print_list();
        }
        else
        {
            head = (struct node *)malloc(sizeof(struct node));
            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            head->data = a;
            head->next = NULL;
            print_list();
        }
    }
    int x = Totaldata(head);
    printf("%\n");
    printf("%d", x);


    return 0;
}
