#include <stdio.h>
#include <stdlib.h>

int main()
{
    //int arr[] = {64, 25, 12, 22, 11};
    int n ,arr[];
    printf("How many value you want to insert?");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    selectionSort(arr, n);
    printArray(arr, n);
    return 0;
}

void selectionSort(int arr[], int n)
{
    int i,j, min, min_i, temp;

    for(i=0; i<=n-1 ;i++)
    {
        min = 9999;
        for(j=i; j<=n-1; j++)
        {
            if(arr[j]<min)
            {
                min = arr[j];
                min_i = j;
            }
        }

        temp = arr[min_i];
        arr[min_i] = arr[i];
        arr[i] = temp;


    }

}
void printArray(int arr[], int size)
{
    int i;

    for (i = 0; i < size; i++)
    {
        printf("%d    ", arr[i]);
    }
}
