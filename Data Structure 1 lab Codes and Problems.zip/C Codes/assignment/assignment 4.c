#include<stdio.h>
#include<stdlib.h>
struct node
{

    int data;
    struct node *next;
    struct node *back;
} typedef node;

struct node *head, *temp, *temp1,*temp2,*temp3;

void sort(node *start)
{
    int tem;
    temp = head;
    while (temp != NULL)
    {
        temp1 = temp->next;
        while (temp1 != NULL)
        {
            if (temp->data > temp1->data)
            {
                tem = temp->data;
                temp->data = temp1->data;
                temp1->data = tem;
            }
            temp1 = temp1->next;
        }
        temp = temp->next;
    }
}
void sortDsc(node *start)
{
    int tem;
    temp = head;
    while (temp != NULL)
    {
        temp1 = temp->next;
        while (temp1 != NULL)
        {
            if (temp->data < temp1->data)
            {
                tem = temp->data;
                temp->data = temp1->data;
                temp1->data = tem;
            }
            temp1 = temp1->next;
        }
        temp = temp->next;
    }
}
struct node* customsort(node* head){
    temp2 = (struct node *)malloc(sizeof(struct node));
    temp1 = (struct node *)malloc(sizeof(struct node));
    temp3 = (struct node *)malloc(sizeof(struct node));
    temp= head;
    while(temp!=NULL){
        if(temp->data%2!=0){
            temp1->data= temp->data;

        }
        else{
            temp2->data=temp->data;
        }
        temp=temp->next;
    }
    sort(temp2);
    sortDsc(temp1);
    while(temp1!=NULL){
        temp3->data=temp1->data;
        temp1=temp1->next;
    }
    while(temp2!=NULL){
        temp3->data=temp2->data;
        temp2=temp2->next;
    }


return temp3;
};
void LastInsertion(int n)
{

    temp1 = head;
    while (temp1->next != NULL)
    {
        temp1 = temp1->next;
    }

    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = NULL;

    temp1->next = temp;
    temp->back = temp1;
}

void print_list()
{
    struct node *t;
    t = head;
    while (t != NULL)
    {
        printf("%d   ", t->data);
        t = t->next;
    }
}

void Fisrt_Insertion(int n)
{
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->back = NULL;
    temp->next = head;
    head->back = temp;
    head = temp;
}

int main()
{

    int a = 1, n, x=0;
    scanf("%d",&n);

    while (x != n)
    {

        if (head != NULL)
        {

            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            if (a != -1)
                // LastInsertion(a);
                Fisrt_Insertion(a);

            print_list();
        }
        else
        {
            head = (struct node *)malloc(sizeof(struct node));
            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            head->data = a;
            head->next = NULL;
            head->back = NULL;
            print_list();
        }
        x++;
    }
    printf("\n");
    sort(head);
    print_list();
    printf("\n");
    sortDsc(head);
    print_list();
    customsort(head);
    print_list();
}
