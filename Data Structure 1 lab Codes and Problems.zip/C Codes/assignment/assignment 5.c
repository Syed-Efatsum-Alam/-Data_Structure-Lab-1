#include<stdio.h>

int main()
{
  float n,i;
    printf("Enter a number\n");
    scanf("%f",&n);
    for(i=0.01;i*i*i<n;i=i+0.01);
    printf("%.3f",i);
    return 0;
}
