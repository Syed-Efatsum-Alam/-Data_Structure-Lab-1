#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
} typedef node;
struct node *head, *temp, *temp1;

void lastInsertion(int n)
{
    temp1 = head;
    while (temp1->next != NULL)
    {
        temp1 = temp1->next;
    }
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = NULL;
    temp1->next = temp;
}
void Fisrt_Insertion(int n)
{
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = head;
    head = temp;
}

void Last_Deletion()
{
    temp1 = head;
    temp = head->next;

    while(temp->next!=NULL)
    {
        temp= temp->next;
        temp1= temp1->next;
    }

    free(temp);
    temp1->next = NULL;
}


void First_Deletion()
{
    temp = head;
    head = head->next;
    //printf("temp %d", temp->data);
    free(temp);
}

void Middle_Deletion(int n)
{
    int i;
    temp = head;

    for(i=1; i<(n-1); i++)
    {
        temp=temp->next;
    }

        temp1 = temp->next;
        temp->next = temp->next->next;
        free(temp1);

}
void print_list()
{
    struct node *t;
    t = head;
    while (t != NULL)
    {
        printf("%d   ", t->data);
        t = t->next;
    }
}
struct node* notMoreThanTwo(node *head, int value){

    head= temp;
    int count=0;
    while(temp!=NULL){
        if(temp->data==value){
            count++;
        }
	temp=temp->next;

    }
    if(count==0){
        Fisrt_Insertion(value);
        printf("%d inserted",value);


    }
    else if(count==1){
        lastInsertion(value);
        printf("%d inserted",value);
    }
    else if(count==2){
        int y=Totaldata();
        int position=0;
        while(temp->data!=value){
            position++;
	    temp=temp->next;
            }
        if(position==1){
                First_Deletion();
                printf("%d deleted",value);
            }
        else if(position==y){
                Last_Deletion();
                printf("%d deleted",value);
            }
        else{
            Middle_Deletion(position);
            printf("%d deleted",value);

            }

    }



}
int Totaldata(node *head)
{

    temp = head;
    int count = 0;
    if (temp->data == -1)
    {
        return 0;
    }
    else
    {
        while (temp != NULL)
        {
            temp = temp->next;
            count++;
        }
    }

    return count;
}


int main()
{

    int a =1,x;

    while (a != -1)
    {

        if (head != NULL)
        {

            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            if (a != -1)
                // LastInsertion(a);
            Fisrt_Insertion(a);
            print_list();
        }
        else
        {
            head = (struct node *)malloc(sizeof(struct node));
            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            head->data = a;
            head->next = NULL;
            print_list();
        }
    }
    printf("Enter the number you want to check for");
    scanf("%d",&x);
    notMoreThanTwo(head,x);
    print_list();

    return 0;
}
