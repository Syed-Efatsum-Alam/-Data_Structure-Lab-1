#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
} typedef node;
struct node *head, *temp, *temp1;

void Fisrt_Insertion(int n)
{
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = head;
    head = temp;
}
void print_list()
{
    struct node *t;
    t = head;
    while (t != NULL)
    {
        printf("%d   ", t->data);
        t = t->next;
    }
}
void seperateOddEven(node *head, int direction){

    int arr[100],arr1[100],arr2[100];
    temp=head;
    int totaldata;
    int i;
    int count1=0;
    int count2=0;

    if(direction==1){

        while(temp!=NULL){
            i=0;
            temp=temp->next;
            if(temp->data%2!=0){
                arr1[i]=temp->data;
                i++;
                count1++;
            }
        }
        while(temp!=NULL){
            i=0;
            temp=temp->next;
            if(temp->data%2==0){
                arr2[i]=temp->data;
                count2++;
            }
        }
        int x=count1;
        for(i=0;i<x;i++){
            arr[i]=arr1[i];
        }
        int y=count1+count2;
        for(i=x;i<y;i++){
            int m=0;
            arr[i]=arr2[m];
            m++;
        }
    }
    if(direction==2){
        while(temp!=NULL){
            i=0;
            temp=temp->next;
            if(temp->data%2!=0){
                arr1[i]=temp->data;
                i++;
                count1++;
            }
        }
        while(temp!=NULL){
            i=0;
            temp=temp->next;
            if(temp->data%2==0){
                arr2[i]=temp->data;
                count2++;
            }
        }
        int x=count2;
        for(i=0;i<x;i++){
            arr[i]=arr2[i];
        }
        int y=count1+count2;
        for(i=x;i<y;i++){
            int m=0;
            arr[i]=arr1[m];
            m++;
        }

    totaldata=y;


    }

    for(int j=0;j<totaldata;j++){
        printf("%d ",arr[j]);
    }


}


int main()
{

    int a = 1;

    while (a != -1)
    {

        if (head != NULL)
        {

            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            if (a != -1)
                // LastInsertion(a);
            Fisrt_Insertion(a);
            print_list();
        }
        else
        {
            head = (struct node *)malloc(sizeof(struct node));
            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            head->data = a;
            head->next = NULL;
            print_list();
        }
    }
    printf("\n");
    seperateOddEven(head,1);


    return 0;
}