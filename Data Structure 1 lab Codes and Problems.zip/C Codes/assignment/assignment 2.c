#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[100],n;
    printf("How many elements do you want to insert?");
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    for(int i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
    int max=1;
    int a=1;
    int highest_occured_value[100];
    for(int i=0;i<n;i++){
        int count=0;
        for(int j=0;j<n;j++){
            if(arr[j]==arr[i]){
                count++;
            }
        }
        if(count>max){
            max=count;
            highest_occured_value[0]=arr[i];

        }
        else if(count==max && highest_occured_value[0]!=i){

            highest_occured_value[a]=arr[i];
            a++;

        }

    }
    printf("\n");

    for(int i=0;i<a;i++){
        printf("%d Occurred %d times",highest_occured_value[i],max);

    }




    return 0;
}



