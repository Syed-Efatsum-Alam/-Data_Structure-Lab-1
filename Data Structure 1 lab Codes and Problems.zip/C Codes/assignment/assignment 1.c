#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data,count1;
    struct node *next;
} typedef node;
struct node *head, *temp, *temp1;

void lastInsertion(int n)
{
    temp1 = head;
    while (temp1->next != NULL)
    {
        temp1 = temp1->next;
    }
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = NULL;
    temp1->next = temp;
}
void Fisrt_Insertion(int n)
{
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = head;
    head = temp;
}

void Last_Deletion()
{
    temp1 = head;
    temp = head->next;

    while(temp->next!=NULL)
    {
        temp= temp->next;
        temp1= temp1->next;
    }

    free(temp);
    temp1->next = NULL;
}


void First_Deletion()
{
    temp = head;
    head = head->next;
    //printf("temp %d", temp->data);
    free(temp);
}

void Middle_Deletion(int n)
{
    int i;
    temp = head;

    for(i=1; i<(n-1); i++)
    {
        temp=temp->next;
    }

        temp1 = temp->next;
        temp->next = temp->next->next;
        free(temp1);

}
void print_list(node*head)
{
    struct node *t;
    t = head;
    while (t != NULL)
    {
        printf("%d   ", t->data);
        t = t->next;
    }
}

void sort(node *start)
{
    int tem;
    temp = head;
    while (temp != NULL)
    {
        temp1 = temp->next;
        while (temp1 != NULL)
        {
            if (temp->data > temp1->data)
            {
                tem = temp->data;
                temp->data = temp1->data;
                temp1->data = tem;
            }
            temp1 = temp1->next;
        }
        temp = temp->next;
    }
}
void sortCount(node *start)
{
    int tem;
    temp = head;
    while (temp != NULL)
    {
        temp1 = temp->next;
        while (temp1 != NULL)
        {
            if (temp->count1 > temp1->count1)
            {
                tem = temp->count1;
                temp->count1 = temp1->count1;
                temp1->count1 = tem;
            }
            temp1 = temp1->next;
        }
        temp = temp->next;
    }
}
int Totaldata(node *head)
{

    temp = head;
    int count = 0;
    if (temp->data == -1)
    {
        return 0;
    }
    else
    {
        while (temp != NULL)
        {
            temp = temp->next;
            count++;
        }
    }

    return count;
}
struct node*customOrder(node*head){
    temp= head;
    temp1=head;
    int x=Totaldata(head);
    while(temp!=NULL){

           while(temp1!=NULL){
            if(temp->data==temp1->data){
                temp->count1++;
            }
                temp1=temp1->next;
           }
           temp=temp->next;

        }
     sortCount(temp);
     print_list(temp);


};


int main()
{

    int a =1,x=0,n;
    printf("How many value you want to insert?");
    scanf("%d",&n);

    while (x != n)
    {

        if (head != NULL)
        {

            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            if (a != -1)
                // LastInsertion(a);
            Fisrt_Insertion(a);
            print_list(head);
        }
        else
        {
            head = (struct node *)malloc(sizeof(struct node));
            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            head->data = a;
            head->next = NULL;
            print_list(head);
        }
        x++;
    }
    printf("\n");
    customOrder(head);


    return 0;
}