// Linked list implementation in C

#include <stdio.h>
#include <stdlib.h>

// Creating a node
struct node {
  int value;
  struct node *next;
};

// print the linked list value
void printLinkedlist(struct node *p) {
  while (p != NULL) {
    printf("%d ", p->value);
    p = p->next;
  }
}

int main() {
    int n=3;
    int temp;
  // Initialize nodes
  struct node *head=NULL;
  struct node *temp=NULL;
  // Allocate memory
  head = malloc(sizeof(struct node));

    head=temp;
  // Assign value values
  for(int i=0;i<n;i++){
    int x;
    scanf("%d",&x);
    temp->value=x;
    temp=temp->next;
    }
    temp->next=NULL;


  // Connect nodes

  // printing node-value

  printLinkedlist(head);
}
