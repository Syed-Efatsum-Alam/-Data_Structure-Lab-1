#include <stdio.h>
int main()
{
   int x, y, z, w, a;
   printf("Enter the value of x= ");
   scanf("%d", &x);
   printf("Enter the value of y= ");
   scanf("%d", &y);
   printf("Enter the value of w= ");
   scanf("%d", &w);
   printf("Enter the value of a=");
   scanf("%d", &a);
   z = x + y + w + a;
   printf("%d", z);
   printf("%d", z + 10 + 10);
}