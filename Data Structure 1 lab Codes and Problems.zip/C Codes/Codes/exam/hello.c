#include <stdio.h>
int main()
{
    int n;
    scanf("%d", &n);
    printf("%d \n", n);
    printf("Hello,hi");
    printf("\n");
    printf("Hi there");
}