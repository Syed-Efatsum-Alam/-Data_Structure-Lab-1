#include <stdio.h>
void inSort(int arr[],int n){

int i,j,temp;
for(i=1;i<n;i++){
 // if (arr[i]!=x)
  {
    
        temp=arr[i];
        j=i-1;

        while(temp>arr[j] && j>=0){
            arr[j+1]=arr[j];
            --j;

        }
        arr[j+1]=temp;
  }
  

}
}

int main()
{
    int ar[]={1,0,2,4,5,6,7,8};
    int ar2[100];
    int x=7; //6//8 7 5 4 6 2 1
    int j;
   

     int n=sizeof ar/sizeof ar[0];
     for(int i=0;i<n;i++){
        if(ar[i]==x){
            j=i;
        }
    }
     
      printf("%d",j);
      printf("\n");
     inSort(ar,n);
     for(int i=0;i<n;i++){
        printf("%d ",ar[i]);
     }
     for(int i=0;i<j-1;i++){
        ar2[i]==ar[i];
     }
     for(int i=0;i<j;i++){
        printf("%d ",ar2[i]);
     } 
    
        ar2[j]=x;

     for(int i=j+1;i<n+1;i++){
        ar2[i]==ar[i];
     } 
     printf("\n"); 

    //   for(int i=0;i<n+1;i++){
    //     printf("%d ",ar2[i]);
    //  } 
    
   
    
    

    
    

    return 0;
}