#include <stdio.h>
int Bsearch(int arr[], int l, int h, int x)
{

    if (h >= l)
    {
        int mid = (h + l) / 2;

        if (x == arr[mid])
        {
            return mid;
        }
        if (arr[mid] > x)
        {

            return Bsearch(arr, l, mid - 1, x);
        }

        return Bsearch(arr, mid + 1, h, x);
    }

    return -1;
}

int main()
{
    int n;
    int arr[10];
    int x;
    scanf("%d", &x);
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    for (int i = 0; i < n; i++)
    {
        printf("%d", arr[i]);
    }
    int r = Bsearch(arr, 0, n - 1, x);
    (r == -1) ? printf("not") : printf("found");
}