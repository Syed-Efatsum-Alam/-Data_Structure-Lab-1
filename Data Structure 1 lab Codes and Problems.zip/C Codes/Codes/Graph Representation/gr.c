#include<stdio.h>

void create_graph(int v,int graph[v][v])
{
    int i,j;

    for(i=1; i<=v; i++)
    {
        for(j=1; j<=v; j++)
        {
            printf("%d has any connect with %d?",i,j);
            scanf("%d", &graph[i][j]);
        }
    }


    // for(i=1; i<=v; i++)
    // {
    //     for(j=1; j<=v; j++)
    //     {
    //         printf("%d -> %d = %d   ",i,j, graph[i][j]);

    //     }
    //     printf("\n");
    // }


    for(i=1; i<=v; i++)
    {
        printf("%d->",i);
        for(j=1; j<=v; j++)
        {
            if(graph[i][j]!=0)
                printf("%d, ",j);

        }
        printf("\n");
    }


}


int main()
{
    int n,g[n][n];
    printf("Enter the number of vertices:");
    scanf("%d",&v);
    create_graph(v,g);
    int u,v;
    scanf("%d",&u);
    scanf("%d",&v);

    if(g[u][v]==1){
        printf("Yes");
        printf("%d->%d",u,v);
    }
    else{
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                if(i=u){
                     if(g[i][j]==1 && g[j][v]==1){
                        printf("yes");
                        printf("\n");
                        printf("%d->%d->%d",u,j,v);

                    }
                    else if(g[i][j]==1&&g[j][j+2]==1&&g[j+2][v]==1)
                    {
                        printf("%d->%d->%d->%d",u,j,j+1,v);

                    }

                }
                
                
            }
        }
    }
       
       


    return 0;
}




                    //                4
                    //                |
                    //                |    
                    //                |
                    //                |
                    //   1-----------3  
                    //   |
                    //   |
                    //   2