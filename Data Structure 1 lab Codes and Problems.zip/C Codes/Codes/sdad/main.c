#include <stdio.h>
#include <stdlib.h>

int main()
{
int m = 20;
int n = 10;
for (int i=1;i<=m ;i++){
        for (int j=1;j<=n;j++){
            if (i==j){
            printf("%d %d",i,j);
             return 10;
            }

        }
    }


return -5;
}
