#include<stdio.h>

int arr[100], top=-1, capacity;

void printStack()
{
    int i;
    for(i=0; i<=top; i++)
        printf("%d   ", arr[i]);

    printf("\n");
}

void push(int n)
{
    if((top+1)==capacity)
        printf("Overflow\n");

    else
    {
        top++;
        arr[top] = n;
    }

}

void pop()
{
    if(top == -1)
        printf("Underflow\n");

    else
    {
        arr[top] = -1;
        top--;
    }
}


int main()
{
    int choice, n;
    printf("Enter the capacity:");
    scanf("%d", &capacity);

    while(1)
    {

        printf("Enter your choice. \n1 to push, \n2 to pop,\n3 to print,\n0 to exit\n");
        scanf("%d", &choice);

        if(choice==1)
        {
            printf("Enter the value you want to push:");
            scanf("%d", &n);
            push(n);
        }
        else if(choice==2) pop();
        else if (choice==3) printStack();
        else if(choice==0) break;

    }

    return 0;
}