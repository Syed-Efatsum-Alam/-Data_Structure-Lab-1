void create_graph(int v, int graph[v][v])
{
    int i, j;

    for (i = 1; i <= v; i++)
    {
        for (j = 1; j <= v; j++)
        {
            printf("%d has any connect with %d?", i, j);
            scanf("%d", &graph[i][j]);
        }
    }

    // for (i = 1; i <= v; i++)
    // {
    //     for (j = 1; j <= v; j++)
    //     {
    //         printf("%d -> %d = %d   ", i, j, graph[i][j]);
    //     }
    //     printf("\n");
    // }

    for (i = 1; i <= v; i++)
    {
        printf("%d->", i);
        for (j = 1; j <= v; j++)
        {
            if (graph[i][j] != 0)
                printf("%d, ", j);
        }
        printf("\n");
    }
}
int main()
{
    int v,graph[v][v];
    printf("Enter the number of vertices:");
    scanf("%d", &v);
    create_graph(v,graph);

    return 0;
}