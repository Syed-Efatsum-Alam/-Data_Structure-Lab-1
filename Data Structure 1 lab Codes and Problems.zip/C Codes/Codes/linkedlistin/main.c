#include <stdio.h>
#include <stdlib.h>



struct list
{
    int data;
    struct list *next;
}*start;
typedef struct list node;

void printLinkedlist(node *start)
{
    node *temp;
    printf("createdlist: ");
    temp=start;
    while (temp != NULL)
    {
        printf("%d ", temp->data);
        temp = temp->next;
    }
}
void insert_at_given_position(int data, int position)
{
    int count = 0;
    node *newNode, *temp;
    newNode = ( node*)malloc(sizeof( node)); // Allocate memory for the node
    if(newNode == NULL)
    {
        printf("Unable to allocate memory.");
    }
    else
    {
        temp = start;
// Traverse to the given position in the list
        while(temp->next != NULL && ((position - 1) != count))
        {
            temp = temp->next;
            count = count + 1;
        }
//Insert the element at the position
        if( (position - 1) == count)
        {
            newNode->data = data;
            newNode->next = temp->next; //Link the inserted node with the next node
            temp->next = newNode; // Link the previous node and the inserted node
        }
    }
}


int main()
{
    int i,n;
    node *start,*prev,*temp;
    printf("How many nodes? ");
    scanf("%d",&n);

    start= (node*)malloc(sizeof (node));
    scanf("%d",&start->data);
    start->next=NULL;
    prev=start;
    for(i=2; i<=n; i++)
    {
        temp=(node*)malloc(sizeof (node));
        scanf("%d",&temp->data);
        temp->next=NULL;
        prev->next=temp;
        prev=temp;
    }
    printLinkedlist(start);

    int x;
    scanf("%d",&x);

    insert_at_given_position(10,x);

    printLinkedlist(start);

//    for(i=1; i<n; i++)
//    {
//        if(i==x)
//        {
//            temp=(node*)malloc(sizeof(node));
//            scanf("%d",&temp->data);
//            temp->next=start->next;
//            start->next=temp;
//
//        }
//
//
//    }



    return 0;
}
