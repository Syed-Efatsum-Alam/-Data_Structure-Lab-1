#include <stdio.h>
#include <stdlib.h>

void selection(int arr[],int n){

int i,j,temp,min_i,min;

for(i=0;i<=n-1;i++){

        min= 999999;

        for(j=i;j<=n-1;j++){

            if(arr[j]<min){
                min=arr[j];
                min_i=j;
            }
        }
        temp=arr[min_i];
        arr[min_i]=arr[i];
        arr[i]=temp;

}

}
void selectionSort(int *arr, int n)
{
    int i, j, min;
    for (i = 0; i < n - 1; i++)
    {
        min = i;
        for (j = i + 1; j < n; j++)
        {
            if (arr[j] > arr[min])
                min = j;
        }
        if (min != i)
        {
            int tmp = arr[i];
            arr[i] = arr[min];
            arr[min] = tmp;
        }
    }
}

void Bsort(int arr[],int n){// 1 4 6 7 8 10 0 5
int i,j;
for(i=0;i<n-1;i++){
    //int temp=arr[i];
    for(j=0;j<n-i-1;j++){
            if(arr[j]>arr[j+1]){
                int temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;

            }

    }
}

}
void inSort(int arr[],int n){

int i,j,temp;
for(i=1;i<n;i++){

        temp=arr[i];
        j=i-1;

        while(temp<arr[j] && j>=0){
            arr[j+1]=arr[j];
            --j;

        }
        arr[j+1]=temp;

}

}
void swap(int x,int y){
    int temp;
    temp=x;
    x=y;
    y=temp;

}


int main(){

    int i;
    int arr[100];
    int n;
    printf("how many data you want to add?\n");
    scanf("%d",&n);

for(i=0;i<n;i++){
    scanf("%d",&arr[i]);
}
printf("The array is\n");
for(i=0;i<n;i++){
    printf("%d ",arr[i]);
}

selectionSort(arr,n);
//inSort(arr,n);
//Bsort(arr,n);
printf("\n");
for(i=0;i<n;i++){
    printf("%d ",arr[i]);
}



}
