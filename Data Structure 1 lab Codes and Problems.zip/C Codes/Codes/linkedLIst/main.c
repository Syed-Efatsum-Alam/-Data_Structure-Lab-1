#include<stdio.h>
#include<stdlib.h>


struct node
{
    int data;
    struct node *next;
} typedef node;

// add a node to the end of the list
void add_node(node **head, int data)
{
    node *new_node = (node *)malloc(sizeof(node));
    new_node->data = data;
    new_node->next = NULL;

    if (*head == NULL)
    {
        *head = new_node;
    }
    else
    {
        node *temp = *head;
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = new_node;
    }
}

// delete a node at a given position
void delete_node_at_pos(node **head, int pos)
{
    node *temp = *head;
    if (pos == 0)
    {
        *head = temp->next;
        free(temp);
    }
    else
    {
        for (int i = 0; i < pos - 1; i++)
        {
            temp = temp->next;
        }
        node *temp2 = temp->next;
        temp->next = temp->next->next;
        free(temp2);
    }
}


void print_list(node *head)
{
    node *temp = head;
    while (temp != NULL)
    {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

// add node at a given position
void add_node_at_pos(node **head, int data, int pos)
{
    node *new_node = (node *)malloc(sizeof(node));
    new_node->data = data;
    new_node->next = NULL;

    node *temp = *head;
    if (pos == 0)
    {
        new_node->next = *head;
        *head = new_node;
    }
    else
    {
        for (int i = 0; i < pos - 1; i++)
        {
            temp = temp->next;
        }
        new_node->next = temp->next;
        temp->next = new_node;
    }
}


int main()
{
  int n, v;
  node *head = NULL;
  scanf("%d", &n);


  for(int i = 0; i < n; i++)
  {
    int tmp;
    scanf("%d", &tmp);
    add_node(&head, tmp);
  }

  scanf("%d", &v);
  if (v%2==0)
    delete_node_at_pos(&head, n-2);
  else
      add_node_at_pos(&head, v, 2);

  print_list(head);
}
