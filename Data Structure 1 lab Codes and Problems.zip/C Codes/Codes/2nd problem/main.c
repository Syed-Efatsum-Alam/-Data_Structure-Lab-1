#include <stdio.h>
#include <stdlib.h>

void inSort(int arr[],int n){

int i,j,temp;
for(i=1;i<n;i++){

        temp=arr[i];
        j=i-1;

        while(temp>arr[j] && j>=0){
            arr[j+1]=arr[j];
            --j;

        }
        arr[j+1]=temp;

    }
}

int main()
{
    int arr[100],arr2[100];
    int n,x,j;
    scanf("%d",&n);
    scanf("%d",&x);

    printf("%d",j);
    for( int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
     for( int i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
    printf("\n");
    for(int i=0;i<n;i++){
        if(arr[i]==x){
           j=arr[i];
        }
    }
    int m=j;

    inSort(arr,n);
     for(int i=0;i<j;i++){
        arr2[i]=arr[i];
    }
    int y=j+1;
    for(y;y<n;y++){
        arr[y]=arr2[y];
    }
    arr2[m]=x;


    printf("\n");

 for( int i=0;i<n+1;i++){
        printf("%d ",arr2[i]);
    }

    return 0;
}
