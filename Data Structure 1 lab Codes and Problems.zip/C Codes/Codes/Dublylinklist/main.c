#include <stdio.h>
#include <stdlib.h>
struct list{

    int data;
    struct list *back,*next;

};
typedef struct list node;
node *head,*temp,*prev,*temp1;

void printDataf(node* start){

    node*temp;
    temp=start;
    printf("Print list: \n");
    while(temp!=NULL){

        printf("%d ",temp->data);
        temp=temp->next;

    }
}
void printDatab(node* prev){

    node*temp;
    temp=prev;
    printf("Print list: \n");
    while(temp!=NULL){
        printf("%d ",temp->back);
        temp=temp->back;
    }
}
//void lastInsertion(int n)
//{
//    temp = (node*) malloc(sizeof(node));
//    temp->data = n;
//    temp->next = NULL;
//    temp->back = prev;
//    prev->next = temp;
//    prev = temp;
//}
void firstInsertion(int n)
{
    temp = (node*) malloc(sizeof(node));
    temp->data = n;
    temp->next = head;
    temp->back = NULL;
    head->back = temp;
    head = temp;
}
void firstDeletion(){
    temp=head;
    head=head->next;
    head->back=NULL;
    free(temp);

}
void lastDeletion(){
    temp=head;
    while(temp!=NULL){
        temp=temp->next;
    }
    temp->back->next=NULL;
    free(temp);

}

void middleInsertion(int n,int v){


    int count;
    while(temp!=NULL){
        temp=temp->next;
        count++;
    }
    printf("%d",count);
    if(n<=count){
            temp=head;
    for(int i=2;i<n;i++){

        temp=temp->next;

    }
    temp1= (node*)malloc(sizeof(node));
    temp1->data=v;
    temp1->next=temp->next;
    temp->next=temp1;
    temp1->back=temp;
    if(temp1->next!=NULL){
            temp1->next->back=temp1;

    }


    }


}
int search(int v){

    temp=head;
    int count=0;
    while(temp!=NULL){
        count++;

            if(temp->data==v){
                return count;
            }
        temp=temp->next;

    }




}
int Totaldata(node* start){

    temp=head;
    int count=0;
    while(temp!=NULL){
        temp=temp->next;
        count++;
    }
    return count;

}
void middleDeletion(int n){

    int count;
    while(temp!=NULL){
        temp=temp->next;
        count++;
    }
    printf("%d",count);
    if(n<=count){
            temp=head;
    for(int i=1;i<=n;i++){

        temp=temp->next;

    }
    temp->back->next=temp->next;
    temp->next->back=temp->back;
    free(temp);
    }

}

int main()

{
        int a = 1,n,v;


    while(a!=-1)
    {
        if(head!=NULL)
        {
            printf("Insert the node value: ");
            scanf("%d",&a);
            if(a!=-1)
            {

                firstInsertion(a);


            }

            printDataf(head);
        }
        else
        {
            printf("Insert the node value: ");
            head = (node*) malloc (sizeof(node));
            scanf("%d",&head->data);
            head->back = NULL;
            head->next = NULL;
            prev = head;
            printDataf(head);
        }
    }
   // printf("\n after middle deletion");
    printf("Enter the value of v");
    scanf("%d",&v);
    int position=search(v);
    int numofElement=Totaldata(head);
//    printf("%d \n",position);


    if(position==0){
            middleInsertion(numofElement/2,v);

    }
    else if(position==1){
        firstDeletion();
    }
    else if(position==numofElement){
        lastDeletion();
    }

    else{
        middleDeletion(position);
    }

    printDataf(head);


    return 0;
}
