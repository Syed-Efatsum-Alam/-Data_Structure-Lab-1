#include<stdio.h>
#include<stdlib.h>


struct node
{

    int data;
    struct node *next;
    struct  node *back;

};

struct node *head, *temp, *temp1;
void sort(head){
    int tem;
    temp=head;
    while(temp!=NULL){
        temp1=temp->next;
        while(temp1!=NULL){
            if(temp->data>temp1->data){
                tem = temp->data;
                temp->data = temp1->data;
                temp1->data = tem;
            }
            temp1=temp1->next;
        }
        temp=temp->next;
    }
}

//void sort(head){
//    struct node *temp7,*temp8;
//    int tem;
//    temp7 = head;
//    while (temp7 != NULL)
//    {
//        temp8 = temp7->next;
//
//        while (temp8 != NULL)
//        {
//            if (temp7->data > temp8->data)
//            {
//                tem = temp7->data;
//                temp7->data = temp8->data;
//                temp8->data = tem;
//            }
//            temp8 = temp8->next;
//        }
//        temp7 = temp7->next;
//}

void LastInsertion(int n)
{
    temp1=head;
    while(temp1->next!=NULL)
    {
        temp1 = temp1->next;
    }


    temp = (struct node*)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = NULL;

    temp1 ->next = temp;
    temp->back= temp1;
}

void print_list()
{
    struct node *t;
    t=head;
    while(t!=NULL)
    {
        printf("%d   ", t->data);
        t=t->next;
    }
}

void Fisrt_Insertion(int n)
{
    temp = (struct node*)malloc(sizeof(struct node));
    temp->data = n;
    temp->back = NULL;
    temp->next = head;
    head->back = temp;
    head = temp;
}
void Middle_Insertion(int a, int k)
{
    int i, count = 0;

    temp=head;
    while(temp!= NULL)
    {
        temp = temp->next;
        count++;
    }

    //printf("count = %d", count);

    if(k<=count)
    {
        temp=head;

        for(i=1; i<(k-1); i++)
        {
            temp=temp->next;
        }

        temp1 = (struct node*)malloc(sizeof(struct node));
        temp1->data = a;

        temp1->next = temp->next;
        temp->next=temp1;
        temp1->back =temp;
        if(temp1->next!=NULL)
         {
             temp1->next->back=temp1;
         }


    }
    else
        printf("Invalid position");


}

int main()
{

    int a=1,n;

    while(a!=-1)
    {


        if(head!=NULL)
        {

            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            if(a!=-1)
                //LastInsertion(a);
            Fisrt_Insertion(a);

            print_list();
        }
        else
        {
            head = (struct node*)malloc(sizeof(struct node));
            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            head->data = a;
            head->next = NULL;
            head->back = NULL;
            print_list();
        }


    }
            printf("Enter the position from where you want to insert");
            scanf("%d", &n);
            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            Middle_Insertion(a,n);
            print_list();
            printf("\n");
            sort(head);
            print_list();


    return 0;
}
