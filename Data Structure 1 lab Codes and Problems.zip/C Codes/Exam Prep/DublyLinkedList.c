#include <stdio.h>
#include <stdlib.h>

struct node
{

    int data;
    struct node *next;
    struct node *back;
} typedef node;

struct node *head, *temp, *temp1;

void sort(node *start)
{
    int tem;
    temp = head;
    while (temp != NULL)
    {
        temp1 = temp->next;
        while (temp1 != NULL)
        {
            if (temp->data > temp1->data)
            {
                tem = temp->data;
                temp->data = temp1->data;
                temp1->data = tem;
            }
            temp1 = temp1->next;
        }
        temp = temp->next;
    }
}

void LastInsertion(int n)
{
    temp1 = head;
    while (temp1->next != NULL)
    {
        temp1 = temp1->next;
    }

    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->next = NULL;

    temp1->next = temp;
    temp->back = temp1;
}

void print_list()
{
    struct node *t;
    t = head;
    while (t != NULL)
    {
        printf("%d   ", t->data);
        t = t->next;
    }
}

void Fisrt_Insertion(int n)
{
    temp = (struct node *)malloc(sizeof(struct node));
    temp->data = n;
    temp->back = NULL;
    temp->next = head;
    head->back = temp;
    head = temp;
}
void Middle_Insertion(int a, int k)
{
    int i, count = 0;

    temp = head;
    while (temp != NULL)
    {
        temp = temp->next;
        count++;
    }

    // printf("count = %d", count);

    if (k <= count)
    {
        temp = head;

        for (i = 1; i < (k - 1); i++)
        {
            temp = temp->next;
        }

        temp1 = (struct node *)malloc(sizeof(struct node));
        temp1->data = a;

        temp1->next = temp->next;
        temp->next = temp1;
        temp1->back = temp;
        if (temp1->next != NULL)
        {
            temp1->next->back = temp1;
        }
    }
    else
        printf("Invalid position");
}

void Last_Deletion()
{
    temp = head;
    // temp = head->next;

    while (temp->next != NULL)
    {
        temp = temp->next;
        // temp1= temp1->next;
    }

    temp->back->next = NULL;

    free(temp);
    // temp1->next = NULL;
}

void First_Deletion()
{
    temp = head;
    head = head->next;
    // printf("temp %d", temp->data);

    head->back = NULL;
    free(temp);
}

void Middle_Deletion(int n) // n= position
{
    int i;
    temp = head;

    for (i = 1; i < n; i++)
    {
        temp = temp->next;
    }

    // temp1 = temp->next;
    // temp->next = temp->next->next;

    temp->back->next = temp->next;
    temp->next->back = temp->back;
    free(temp);
}

int main()
{

    int a = 1, n, x;

    while (a != -1)
    {

        if (head != NULL)
        {

            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            if (a != -1)
                // LastInsertion(a);
                Fisrt_Insertion(a);

            print_list();
        }
        else
        {
            head = (struct node *)malloc(sizeof(struct node));
            printf("ENTER THE VALUE YOU WANT TO INSERT");
            scanf("%d", &a);
            head->data = a;
            head->next = NULL;
            head->back = NULL;
            print_list();
        }
    }
    printf("Enter the position from where you want to insert");
    scanf("%d", &n);
    printf("ENTER THE VALUE YOU WANT TO INSERT");
    scanf("%d", &a);
    Middle_Insertion(a, n);
    print_list();
    printf("\n");
    printf("Sorted Linked List: ");
    sort(head);
    print_list();
    printf("\n");
    printf("WHich postion's Value you wanna delete?");
    scanf("%d", &x);
    Middle_Deletion(x);
    print_list();

    return 0;
}
