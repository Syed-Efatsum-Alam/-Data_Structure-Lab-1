#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[10], B[10];
    int n;

    printf("How many value you want to insert?");
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    // printArray(arr, n);
    //  bubbleSort(arr, n);
    //  printf("\n");
    //  printArray(arr, n);
    int j = 0;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] % 2 == 0)
        {
            B[j] = arr[i];
            j++;
        }
    }
    printf("position occupied=%d", j);
    printf("\n");
    int n2 = sizeof(B) / sizeof(B[0]);
    printArray(B, n2);

    for (int i = 0; i < n; i++)
    {
        if (arr[i] % 2 != 0)
        {
            B[j] = arr[i];
            j++;
        }
    }
    printf("\n");
    printArray(B, n);
    bubbleSortDesc(B, n);
    printf("\n");
    printArray(B, n);

    // int Barray= sizeof(B)/sizeof(B[0]);
    // bubbleSort(B,Barray);
    // for(int i=Barray-1;i<n;i++){

    // }
}
// ascending order
void selectionSort(int arr[], int n)
{
    int i, j, min, min_i, temp;

    for (i = 0; i <= n - 1; i++)
    {
        min = 9999;
        for (j = i; j <= n - 1; j++)
        {
            if (arr[j] < min)
            {
                min = arr[j];
                min_i = j;
            }
        }

        temp = arr[min_i];
        arr[min_i] = arr[i];
        arr[i] = temp;
    }
}
void insertionSort(int arr[], int n)
{
    int i, key, j;
    for (i = 1; i < n; i++)
    {
        key = arr[i];
        j = i - 1;

        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}
void bubbleSort(int arr[], int n)
{
    int i, j, temp;
    for (i = 0; i < n - 1; i++)
    {

        for (j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}
void bubbleSortDesc(int arr[], int n)
{
    int i, j, temp;
    for (i = 0; i < n - 1; i++)
    {

        for (j = 0; j < n - i - 1; j++)
        {
            if (arr[j] < arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void printArray(int arr[], int size)
{
    int i;

    for (i = 0; i < size; i++)
    {
        printf("%d    ", arr[i]);
    }
}