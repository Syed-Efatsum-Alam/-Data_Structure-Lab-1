// Input an array and do a binary search. if the value v is found then find its closest value.

#include <stdio.h>
#include <stdlib.h>

int BinarySearch(int arr[], int low, int high, int k)
{
    int mid;
    while (low <= high)
    {
        mid = (low + high) / 2;
        if (k == arr[mid])
        {
            return mid;
        }
        else if (k > arr[mid])
        {
            low = mid + 1;
        }
        else
        {
            high = mid - 1;
        }
    }
    return -1;
}
void bubbleSort(int arr[], int n)
{
    int i, j, temp;
    for (i = 0; i < n - 1; i++)
    {

        for (j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main()
{

    int arr[100], n, key;
    printf("How many Value do you want to enter?");
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
    scanf("%d", &key);
    int BSearchResult = BinarySearch(arr, 0, n, key);
    printf("%d \n", BSearchResult);
    int close = 99999, small;
    int x, y;
    if (BSearchResult != 0)
    {
        for (int i = 0; i < n; i++)
        {
            x = arr[BSearchResult] - arr[i];
            y = abs(x);
            printf("x=%d", x);
            if (y < close && y != 0)
            {
                small = arr[i];
                close = y;
            }
        }
    }

    printf("\n");
    printf("The closest=%d", small);
}