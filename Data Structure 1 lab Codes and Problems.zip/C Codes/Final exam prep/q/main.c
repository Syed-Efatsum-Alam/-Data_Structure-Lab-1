#include<stdio.h>

int arr[100], top=-1, capacity;

void printQueue()
{
    int i;
    for(i=0; i<=top; i++)
        printf("%d   ", arr[i]);

    printf("\n");
}

void enqueue(int n)
{
    if((top+1)==capacity)
        printf("Overflow\n");

    else
    {
        top++;
        arr[top] = n;
    }

}

void dequeue()
{
    int i;
    if(top == -1)
        printf("Underflow\n");

    else
    {
        arr[0] = -1;
        for(i = 0; i<top; i++)
        {
            arr[i] = arr[i+1];
        }

        top--;
    }
}


int main()
{
    int choice, n;
    printf("Enter the capacity:");
    scanf("%d", &capacity);

    while(1)
    {

        printf("Enter your choice. \n1 to enqueue, \n2 to dequeue,\n3 to print,\n0 to exit\n");
        scanf("%d", &choice);

        if(choice==1)
        {
            printf("Enter the value you want to push:");
            scanf("%d", &n);
            enqueue(n);
        }
        else if(choice==2) dequeue();
        else if (choice==3) printQueue();
        else if(choice==0) break;

    }

    return 0;
}
