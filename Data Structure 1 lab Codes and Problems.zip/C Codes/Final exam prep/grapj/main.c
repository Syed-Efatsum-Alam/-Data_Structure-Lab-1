#include<stdio.h>

void create_graph(int v)
{
    int graph[100][100],i,j;

    for(i=1; i<=v; i++)
    {
        for(j=1; j<=v; j++)
        {
            printf("%d has any connect with %d?",i,j);
            scanf("%d", &graph[i][j]);
        }
    }


    for(i=1; i<=v; i++)
    {
        for(j=1; j<=v; j++)
        {
            printf("%d -> %d = %d   ",i,j, graph[i][j]);

        }
        printf("\n");
    }


    for(i=1; i<=v; i++)
    {
        printf("%d->",i);
        for(j=1; j<=v; j++)
        {
            if(graph[i][j]!=0)
                printf("%d, ",j);

        }
        printf("\n");
    }


}


int main()
{
    int v;
    printf("Enter the number of vertices:");
    scanf("%d",&v);
    create_graph(v);


    return 0;
}
