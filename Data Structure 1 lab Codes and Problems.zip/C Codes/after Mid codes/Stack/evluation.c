#include <stdio.h>

int arr[100], top = -1, capacity;

void printQueue()
{
    for (int i = 0; i <= top; i++)
        printf("%d   ", arr[i]);
    printf("\n");
}

void enqueue(int n)
{
    if ((top + 1) == capacity)
        printf("Overflow\n");
    else
    {
        top++;
        arr[top] = n;
    }
}

void enqueueFirst(int n)
{
    if ((top + 1) == capacity)
        printf("Overflow\n");
    else
    {
        // shift elements
        for (int i = top + 1; i > 0; i--)
            arr[i] = arr[i - 1];
        top++;
        // put element at the first
        arr[0] = n;
    }
}

void dequeue()
{
    int i;
    if (top == -1)
        printf("Underflow\n");
    else
    {
        arr[0] = -1;
        for (i = 0; i < top; i++)
            arr[i] = arr[i + 1];
        top--;
    }
}

int isVowel(char ch)
{
    char arr = {'a', 'e', 'i', 'o', 'u'};
    for (int i = 0; i < 5; i++)
        if (arr[i] == ch)
            return 1;
    return 0;
}

int main()
{
    char ch;
    int choice, n;
    printf("Enter the queue capacity:");
    scanf("%d", &capacity);
    printf("Enter the array size:");
    scanf("%d", &n);

    printf("Enter the array elements:");
    for (int i = 0; i < n; i++)
    {
        int tmp;
        scanf("%d", &tmp);
        enqueue(tmp);
    }

    printf("Enter the char:");
    // getchar();    // Enable if doesn't ask char input
    scanf("%c", &ch);

    if (isVowel(ch))
        enqueueFirst((int)ch);
    else
        dequeue();

    return 0;
}