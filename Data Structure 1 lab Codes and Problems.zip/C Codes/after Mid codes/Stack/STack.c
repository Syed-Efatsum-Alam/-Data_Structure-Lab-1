#include <stdio.h>
#include <stdlib.h>

void Push(int size, int arr[])
{
    int x;
    printf("Enter the value you want to enter?");
    scanf("%d", x);
    int Top = -1;

    if (Top == size - 1)
    {
        printf("\n Stack OverFlow!!");
    }
    else
    {
        Top = Top + 1;
        arr[Top] = x;
    }
}

void Pop(int arr[])
{
    int Top = -1;
    if (Top == -1)
    {
        printf("Stack Overflow!!");
    }
    else
    {
        printf("Popped Element : %d", arr[Top]);
        Top = Top - 1;
    }
}

void show(int arr[])
{

    int Top = -1;
    if (Top == -1)
    {
        printf("\nUnderflow!!");
    }
    else
    {
        printf("\nElements present in the stack: \n");
        for (int i = Top; i >= 0; --i)
            printf("%d\n", arr[i]);
    }
}

int main()
{
    int choice, arr[100], size;
    size = 5;

    while (1)
    {
        printf("\nOperations performed by Stack");
        printf("\n1.Push the element\n2.Pop the element\n3.Show\n4.End");
        printf("\n\nEnter the choice:");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            Push(size, arr);
            break;
        case 2:
            Pop(arr);
            break;
        case 3:
            show(arr);
            break;
        case 4:
            exit(0);

        default:
            printf("\nInvalid choice!!");
        }
    }
}
